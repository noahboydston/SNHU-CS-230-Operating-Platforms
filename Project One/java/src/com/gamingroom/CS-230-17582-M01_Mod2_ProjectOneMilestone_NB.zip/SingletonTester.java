package com.gamingroom;

/**
 * A class to test a singleton's behavior
 * 
 * @author coce@snhu.edu
 */
public class SingletonTester {

	public void testSingleton() {
		
		System.out.println("\nAbout to test the singleton...");
		
		// FIXED: obtain local reference to the singleton instance
		
		// Call the Singleton GameService constructor method to instantiate a
		// GameService object.
		// If a GameService instance already exists, output message to console
		// indicating instance is already created.
		
		GameService service = GameService.createGameService(); // replace null with ???
		
		// a simple for loop to print the games
		for (int i = 0; i < service.getGameCount(); i++) {
			System.out.println(service.getGame(i));
		}

	}
	
}
